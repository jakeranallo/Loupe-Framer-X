import * as React from "react";
import { PropertyControls, ControlType } from "framer";
import FeatherIcon from "feather-icons-react";
import MaterialIcon from "material-icons-react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import * as Icons from "@fortawesome/free-regular-svg-icons";

// Define type of property
interface Props {
  icon: string;
  width: number;
  height: number;
  color: string;
  set: "feather" | "material" | "fontawesome";
}

export class Icon extends React.Component<Props> {
  // Set default properties
  static defaultProps = {
    icon: "faAddressBook",
    width: 24,
    height: 24,
    color: "#000",
    set: "fontawesome",
  };

  // Items shown in property panel
  static propertyControls: PropertyControls = {
    set: {
      type: ControlType.Enum,
      title: "Set",
      options: ["feather", "material", "fontawesome"],
      optionTitles: ["Feather", "Material", "Font Awesome"],
    },
    icon: { type: ControlType.String, title: "Icon" },
    color: { type: ControlType.Color, title: "Color" },
  };

  render() {
    let RenderIcon = (props: { set: string }) => {
      let name = `${this.props.icon.toLowerCase()}`;
      let faName = `${this.props.icon.toLowerCase()}`;
      faName.replace(/-/g, " ");
      if (props.set === "feather") {
        return (
          <FeatherIcon
            icon={name}
            size={this.props.width}
            color={this.props.color}
          />
        );
      }
      if (props.set === "material") {
        return (
          <MaterialIcon
            icon={name}
            size={this.props.width}
            color={this.props.color}
          />
        );
      }
      if (props.set === "fontawesome") {
        return (
          <FontAwesomeIcon
            icon={Icons[this.props.icon]}
            style={{ width: this.props.width, height: this.props.height }}
            color={this.props.color}
            fixedWidth={true}
          />
        );
      }
    };

    return (
      <div>
        <RenderIcon set={this.props.set} />
      </div>
    );
  }
}
